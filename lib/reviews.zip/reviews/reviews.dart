import 'package:flutter/material.dart';
import 'package:serves/reviews/reviewsmodel.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:intl/intl.dart';

class ReviewScreen extends StatelessWidget {
   ReviewScreen({Key? key}) : super(key: key);

  Future<ReviewsModel> fetchAllData() async {
    final response =
        await http.get(Uri.parse('http://localhost:8000/GetAllReviews'));
    var data = jsonDecode(response.body.toString());
    if (response.statusCode == 200) {
      return ReviewsModel.fromJson(data);
    } else {
      return ReviewsModel.fromJson(data);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:  Text('Reviews'),
        centerTitle: true,
      ),
      body: FutureBuilder(
        future: fetchAllData(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return Center(
              child: CircularProgressIndicator(),
            );
          }
          // Add a return statement here if necessary
          return ListView.builder(
            itemCount: 5,
            itemBuilder: (BuildContext context, int index) {
              return Padding(
                padding:  EdgeInsets.all(8.0),
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10.0),
                    border: Border.all(
                      color: Colors.grey.shade300,
                      width: 1.0,
                    ),
                  ),
                  child:  Padding(
                    padding:  EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                Icon(
                                  Icons.person,
                                  size: 40.0,
                                ),
                                SizedBox(width: 8.0),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                     Text(
                                     snapshot.data!.data![index].userId.toString(),
                                       style: TextStyle(
                                        fontSize: 16.0,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    SizedBox(height: 4.0),
                                    Text(
DateFormat('MMMM dd, yyyy').format(DateTime.parse(snapshot.data!.data![index].createdAt.toString())),
                                      style: TextStyle(
                                        color: Colors.grey,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                             Row(
                              children:  [
                               const Icon(
                                  Icons.star,
                                  color: Colors.amber,
                                ),
                                SizedBox(width: 4.0),
                                Text(
                                  snapshot.data!.data![index].stars.toString(),
                                  style: TextStyle(
                                    fontSize: 16.0,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                        const SizedBox(height: 16.0),
                         Text(
                          snapshot.data!.data![index].review.toString(),
                          style: TextStyle(
                            fontSize: 16.0,
                            height: 1.5,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
